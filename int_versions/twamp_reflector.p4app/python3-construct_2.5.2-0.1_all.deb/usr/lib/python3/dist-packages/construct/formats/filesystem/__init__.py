"""
file systems on-disk formats (ext2, fat32, ntfs, ...) 
and related disk formats (mbr, ...)
"""
